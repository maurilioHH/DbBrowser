import { SearchTablesRequest } from './../../model/search-tables-request';
import { Component, DestroyRef, inject, OnDestroy, OnInit, output, signal } from '@angular/core';
import { DatabaseService } from '../../services/database.service';
import { DbConfigMap } from '../../model/db-config.model';
import { AbstractControl, FormBuilder, FormControl, FormGroup, ValidationErrors, ValidatorFn, Validators } from '@angular/forms';
import { ReactiveFormsModule } from '@angular/forms';
import { KeyValuePipe } from '@angular/common';
import { InfoTabella } from '../../model/info-tabella';
import { ListaTabella } from './lista-tabelle/lista-tabella.component';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { NgbDropdownModule } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-ricerca-tabella',
  imports: [ReactiveFormsModule, KeyValuePipe, ListaTabella, NgbDropdownModule],
  templateUrl: './ricerca-tabella.component.html',
  styleUrl: './ricerca-tabella.component.css',
})

export class RicercaTabellaComponent implements OnInit {
  databaseService = inject(DatabaseService);
  formBuilder = inject(FormBuilder);

  databases: DbConfigMap | undefined;
  //listaTabelle?: InfoTabella[] = undefined;
  listaTabelle = signal<InfoTabella[] | undefined>(undefined);
  listaOwners = signal<string[] | undefined>(undefined);

  tabellaSelezionata = output<InfoTabella | undefined>();
  navItem = output<number>();

  tipologieSelezionate: string[] = [];

  private destroyRef = inject(DestroyRef);

  dbFormGroup = new FormGroup(
    {
      database: new FormControl('tutti', { updateOn: 'change' }),
      owner: new FormControl('', {
        validators: [Validators.minLength(3)],
      }),
      nomeTabella: new FormControl('', {
        validators: [Validators.minLength(3)],
      }),
      tipologia: new FormControl('tutte'),
    },
    {
      validators: almenoUnoObbligatorioValidator,
    },
  );

  ngOnInit(): void {
    this.databaseService.getDatabases()
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe({
        next: (data) => {
          this.databases = data;
        },
      });

    this.dbFormGroup.controls.nomeTabella.valueChanges
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe((nuovoValore) => {
        console.log(nuovoValore);
        this.listaTabelle.set(undefined);
      });
  }

  onSelectDatabase() {
    // Recuperiamo il valore direttamente dal form control
    const selectedDb = this.dbFormGroup.controls.database.value;

    this.listaOwners.set(undefined);
    this.listaTabelle.set(undefined);
    this.dbFormGroup.controls.owner.setValue(null);
    this.dbFormGroup.controls.nomeTabella.setValue(null);

    this.tabellaSelezionata.emit(undefined);

    // Gestione di "Tutti" o valore nullo
    if (!selectedDb || selectedDb === 'tutti') {
      // Gestisci il caso in cui non ci sia un DB specifico (es. svuota o ferma la chiamata)
      return;
    }

    const ownersSubscription = this.databaseService
      .searchOwners(selectedDb) // Non serve più l'operatore '!'
      .subscribe({
        next: (data) => {
          this.listaOwners.set(data);
        },
      });
    this.destroyRef.onDestroy(() => ownersSubscription.unsubscribe());
  }

  onSelectOwner() {
    this.listaTabelle.set(undefined);
  }
  
  onSelectTipologia(){
    this.listaTabelle.set(undefined);
  }

  onSubmit() {
    let request: SearchTablesRequest = {
      databaseName: this.dbFormGroup.controls.database.value === 'tutti' ? null : this.dbFormGroup.controls.database.value,
      owner: this.dbFormGroup.controls.owner.value ?? undefined,
      tableName: this.dbFormGroup.controls.nomeTabella.value ?? undefined,
      tipologia: this.dbFormGroup.controls.tipologia.value === 'tutte' ? null : this.dbFormGroup.controls.tipologia.value
    };

    this.databaseService.searchTables(request)
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe({
        next: (data) => {
          this.listaTabelle.set(data);
        },
      });
    
  }

  onReset() {
    this.dbFormGroup.reset({
      database: 'tutti', // Ripristina il valore iniziale se vuoi
      owner: '',
      nomeTabella: '',
    });
    this.dbFormGroup.updateValueAndValidity();

    this.listaOwners.set(undefined);
    this.listaTabelle.set(undefined);
    this.tabellaSelezionata.emit(undefined);
  }

  onTabellaSelezionata(tabella: InfoTabella) {
    this.tabellaSelezionata.emit(tabella);
    this.navItem.emit(2);
  }

  onChangeTipologia(option: string, event: Event): void {
    const isChecked = (event.target as HTMLInputElement).checked;

    if (isChecked) {
      // Aggiungi l'opzione se è stata spuntata
      this.tipologieSelezionate.push(option);
    } 
    else {
      // Rimuovila se è stata tolta la spunta
      this.tipologieSelezionate = this.tipologieSelezionate.filter(item => item !== option);
    }

    console.log('Elementi selezionati:', this.tipologieSelezionate);
  }

}

export const almenoUnoObbligatorioValidator: ValidatorFn = (control: AbstractControl): ValidationErrors | null => {

  // Se il controllo non è ancora pronto, evita controlli a vuoto
  if (!control) return null;

  const database = control.get('database')?.value;
  // Forza il valore a stringa vuota se è null o undefined
  const nomeTabella = control.get('nomeTabella')?.value || '';

  // Se il database è 'tutti' o null e la tabella è vuota
  if ((database === null || database === 'tutti') && nomeTabella.trim() === '') {
    // Il form è INVALIDO
    return { tabellaRichiestaConTutti: true };
  }

  // In tutti gli altri casi il form è valido
  return null;
};

